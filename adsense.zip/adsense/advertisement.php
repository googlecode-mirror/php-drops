<?php
mysql_connect("localhost","root");
mysql_select_db("test");

$ad_details=@mysql_fetch_array(mysql_query("select * from advertisements where id=".$_GET['ad_id']));
if(!empty($ad_details)){

	mysql_query("insert into adsense_track set ip='".$_SERVER['REMOTE_ADDR']."', dt='".date("Y-m-d H:i:s",time())."', imgid='".$_GET['ad_id']."'");
	$im=imagecreatefromjpeg($ad_details['img']);
	header("content-type: image/jpeg");
	imagejpeg($im,null,100);
}else{
	
	$im=imagecreatefromjpeg("noimage.jpg");
	header("content-type: image/jpeg");
	imagejpeg($im,null,100);
}

	