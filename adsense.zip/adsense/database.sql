# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     test
# Server version:               5.1.41
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2011-04-06 18:29:47
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping structure for table test.adsense_track
DROP TABLE IF EXISTS `adsense_track`;
CREATE TABLE IF NOT EXISTS `adsense_track` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(30) DEFAULT NULL,
  `dt` datetime DEFAULT NULL,
  `imgid` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

# Dumping data for table test.adsense_track: 0 rows
DELETE FROM `adsense_track`;
/*!40000 ALTER TABLE `adsense_track` DISABLE KEYS */;
/*!40000 ALTER TABLE `adsense_track` ENABLE KEYS */;


# Dumping structure for table test.advertisements
DROP TABLE IF EXISTS `advertisements`;
CREATE TABLE IF NOT EXISTS `advertisements` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `img` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

# Dumping data for table test.advertisements: 3 rows
DELETE FROM `advertisements`;
/*!40000 ALTER TABLE `advertisements` DISABLE KEYS */;
INSERT INTO `advertisements` (`id`, `img`) VALUES (1, 'ad001.jpg'), (2, 'ad002.jpg'), (3, 'ad003.jpg');
/*!40000 ALTER TABLE `advertisements` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
