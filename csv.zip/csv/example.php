<html>
	<head>
		<title>PHP Drops :: CSV to Database (Sample)</title>
	</head>
	<body>
		<?php
		mysql_connect("localhost","root");
		mysql_select_db("test");
		?>
		<table width="400px" border=1>
		<?php
		if (($handle = fopen("sample.csv", "r")) !== FALSE) {
			$i=0;
			while (($data = fgetcsv($handle, 0, ",")) !== FALSE) 
			{
				
				if($i>0){
					$q="insert into csv_table set id='".$data[0]."', username='".$data[1]."', phone='".$data[2]."', email='".$data[3]."'";
					mysql_query($q);
				}
				?>
					<tr>
						<?php
						foreach($data as $rec){
							echo '<td>'.$rec.'</td>';
						}
						?>
					</tr>
				<?php
				$i++;
			}
		}
		fclose($handle);
		?>
		</table>
	</body>
</html>