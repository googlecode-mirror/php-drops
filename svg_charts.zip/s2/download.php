<?php
session_start();
$file="cache/chart".session_id().".png";
$ext=array_pop(explode(".",$file));
header("Cache-Control: public");
header("Content-Description: File Transfer");
header("Content-Disposition: attachment; filename=$file");
header("Content-Type: application/".$ext);
header("Content-Transfer-Encoding: binary");
readfile($file);
?>