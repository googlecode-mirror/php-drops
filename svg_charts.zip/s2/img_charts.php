<?php
session_start();
class JPGCharts
{
	var $type;
	var $data;
	var $chart_data;
	var $x_data;
	var $y_data;
	var $chart_content;
	var $cbase_y;
	var $cbase_x;
	var $cbar_width;
	var $cbar_gap;
	var $chart_width;
	var $chart_height;
	var $fill_color;
	var $stroke_color;
	var $max_radius;
	var $max_val;
	var $hzoom;
	var $p_radius;
	var $pie_center;
	var $pie_shade;
	
	function __construct($width,$height)
	{
		$this->chart_width=$width;
		$this->chart_height=$height;
		$this->type="bar";
		$this->cbase_x="50";
		$this->cbar_width="10";
		$this->cbar_gap="15";
		$this->fill_color="rgb(0,130,240)";
		$this->stroke_color="rgb(150,0,0)";
		$this->max_radius="10";
		$this->p_radius="90";
		$this->pie_center=array('100','100');
		$this->pie_shade=array(0,120,200);
		
	}
	
	public function set($setType,$value)
	{
		switch($setType){
			case 'chart_type':$this->type=$value;break;
			case 'chart_data':$this->chart_data=$value;break;
			case 'max_height':$this->cbase_y=$value;break;
			case 'left_margin':$this->cbase_x=$value;break;
			case 'bar_width':$this->cbar_width=$value;break;
			case 'bar_gap':$this->cbar_gap=$value;break;
			case 'fill_color':$this->fill_color=$value;break;
			case 'stroke_color':$this->stroke_color=$value;break;
			case 'p_radius':$this->p_radius=$value;break;
			case 'pie_center':$this->pie_center=explode(",",$value);break;
			case 'pie_fill':{
				if($value=="red"){$this->pie_shade=array(250,0,0);}
				if($value=="green"){$this->pie_shade=array(0,250,0);}
				if($value=="blue"){$this->pie_shade=array(0,130,250);}
				break;
			};
		}
	}
	
	public function get($getType){
		switch($getType){
			case 'chart_type':return $this->type;break;
			case 'chart_data':return $this->chart_data;break;
		}
	}
	
	private function init(){
		$this->x_data=$this->chart_data['x'];
		$this->y_data=$this->chart_data['y'];
		$col_width=(int)$this->chart_width / sizeof($this->x_data);
		$this->cbar_width=$col_width-$this->cbar_gap;
		
		$this->cbase_y=0;
		$this->max_val=0;
		foreach($this->y_data as $key=>$val){
			if($val>$this->cbase_y){$this->cbase_y=$val;$this->max_val=$val;}
		}
		$this->cbase_y=$this->cbase_y * 1.3;
		$this->hzoom=$this->chart_height / $this->cbase_y;
		$this->cbase_y=$this->chart_height;
		$this->p_radius=(($this->chart_width-100)/2);
		$this->pie_center=array((($this->chart_width-100)/2),(($this->chart_height)/2));
	}
	
	private function create_sets_area(&$im)
	{
		$content='';

		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		
		$points="";
		$buffer=0;
		$first="";
		$last="";
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=$this->y_data[$i]*$this->hzoom;
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$points.=$x+ ($bar_width/2).",".$y.",";
			if($first==""){$first=$x+ ($bar_width/2);}
			$last=$x+ ($bar_width/2);
		}
		$points=$first.",".$this->chart_height.",".substr($points,0,strlen($points)-1).",".$last.",".$this->chart_height;
		$points_final=explode(",",$points);
		
		
		$fill=str_replace("rgb(","",$this->stroke_color);
		$fill=str_replace(")","",$fill);
		$fill=explode(",",$fill);
		$color = imagecolorallocatealpha($im, (int)$fill[0], (int)$fill[1], (int)$fill[2],103);
		
		imagefilledpolygon($im, $points_final, sizeof($points_final)/2, $color);
			
		return $content;
	}
	
	private function create_sets_pie(&$im)
	{
	
		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		$total=0;
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$total+=$this->y_data[$i];
		}
		
		$long=$this->p_radius;
		$def_x=$this->pie_center[0];
		$def_y=$this->pie_center[1] - $long;
		$colors=$this->pie_shade;
		$prev_deg=0;
		$content_text='';
		$prev2=-90;
		$black = imagecolorallocate($im, 0, 0, 0);
		$font_file = './verdana.ttf';
		for($i=0;$i<sizeof($this->y_data);$i++)
		{
			$act_degree=($this->y_data[$i]/$total) * 360;
			$degrees=($act_degree) - 90 + $prev_deg;

			$act_degreet=(($this->y_data[$i]/$total) * 360)/2;
			$degreest=($act_degreet) - 90 + $prev_deg;
			$yt=$this->pie_center[1] + ($long*sin(deg2rad($degreest)));
			$xt=$this->pie_center[0] + ($long*cos(deg2rad($degreest)));
			
			$y=$this->pie_center[1] + ($long*sin(deg2rad($degrees)));
			$x=$this->pie_center[0] + ($long*cos(deg2rad($degrees)));
			
			$color = imagecolorallocate($im, $colors[0], $colors[1], $colors[2]);
			imagefilledarc($im,$this->pie_center[0],$this->pie_center[1],($long * 2),($long * 2),$prev2,(int)($prev2 + $act_degree),$color,IMG_ARC_PIE);
			
			if($act_degree<=180)
			{
				imagefttext($im, 8, 0, $xt	, $yt +15, $black, $font_file, number_format(($this->y_data[$i]/$total) * 100,2) . "%");
			}
			else{
				$act_degree_2=$act_degree/2;
				$degrees_2=($act_degree_2) - 90 + $prev_deg;
				$y=$this->pie_center[1] + ($long*sin(deg2rad($degrees_2)));
				$x=$this->pie_center[0] + ($long*cos(deg2rad($degrees_2)));
				$prev_deg=$degrees_2 + 90;
				imagefttext($im, 8, 0, $x, $y+15, $black, $font_file, number_format(($this->y_data[$i]/$total) * 100,2) . "%");
			}
			
			$prev_deg=$degrees + 90;
			$prev2=$act_degree + $prev2;

			
			imagefilledrectangle ($im,($this->chart_width-55), (($i+1)*14)-$buffer, ($this->chart_width-55) + 10 , (($i+1)*14)-$buffer + 10, $color);
			imagefttext($im, 8, 0, ($this->chart_width-55) +15	, (($i+1)*14) +10, $black, $font_file, ($this->x_data[$i]).'('.$this->y_data[$i].')');
						
			if($colors[0]>0){$colors[0]=$colors[0] - 30;}
			if($colors[1]>0){$colors[1]=$colors[1] - 30;}
			if($colors[2]>0){$colors[2]=$colors[2] - 30;}
			
				
		}
		
	}
	
	private function create_sets_scatter(&$im)
	{
		$content='';

		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		
		$fill=str_replace("rgb(","",$this->fill_color);
		$fill=str_replace(")","",$fill);
		$fill=explode(",",$fill);
		$color = imagecolorallocate($im, $fill[0], $fill[1], $fill[2]);
		$black = imagecolorallocate($im, 0, 0, 0);
		$font_file = './verdana.ttf';
		
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=$this->y_data[$i]*$this->hzoom;
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$radius=(int)(($ro/($this->max_val*$this->hzoom)) * ($this->max_radius *2));
			imagefilledellipse($im, ($x+($bar_width/2)), $y, $radius, $radius, $color);
			imagefttext($im, 8, 90, ($x + ($bar_width/2)), ($base_y+30+10), $black, $font_file, ($this->x_data[$i]));
		}
		return $content;
	}
	
	private function create_sets_line(&$im)
	{
		$content='';
		
		$prev_x=0;
		$prev_y=0;
		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		$points=array();
		
		$stroke=str_replace("rgb(","",$this->stroke_color);
		$stroke=str_replace(")","",$stroke);
		$stroke=explode(",",$stroke);
		imagesetthickness($im, "5");
		$axis_lines = imagecolorallocate($im, (int)$stroke[0], (int)$stroke[1], (int)$stroke[2]);
		$black = imagecolorallocate($im, 0, 0, 0);
		$white = imagecolorallocate($im, 255, 255, 255);
		$font_file = './verdana.ttf';
			
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=$this->y_data[$i]*$this->hzoom;
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$points[$i]=array($x + ($bar_width/2),$y);
			if($prev_x!=0){
				imageline($im, ($prev_x + ($bar_width/2)), $prev_y, ($x+ ($bar_width/2)), $y, $axis_lines);
			}
			imagefttext($im, 8, 90, ($x + ($bar_width/2)), ($base_y+30+10), $black, $font_file, ($this->x_data[$i]));
			
			
			$prev_x=$x;	
			$prev_y=$y;
		}
		$i=0;
		foreach($points as $key=>$val){
			
			imagefilledellipse($im, ($val[0]), $val[1], 8, 8, $axis_lines);
			imagesetthickness($im, "6");
			imageellipse($im, ($val[0]), $val[1], 10, 10, $white);
			$i++;
		}
	}
	
	private function create_sets_bar(&$im)
	{
		$content='';
		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		$buffer=0;
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=($this->y_data[$i]*$this->hzoom);
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$fill=str_replace("rgb(","",$this->fill_color);
			$fill=str_replace(")","",$fill);
			$fill=explode(",",$fill);
			$color = imagecolorallocate($im, $fill[0], $fill[1], $fill[2]);
			$black = imagecolorallocate($im, 0, 0, 0);
			$font_file = './verdana.ttf';
			imagefilledrectangle ($im, $x, $y-$buffer, $x+$bar_width ,$y+$h -$buffer, $color);
			imagefttext($im, 8, 90, ($x + ($bar_width/2)), ($base_y+30+10), $black, $font_file, ($this->x_data[$i]));
		}
	}
	
	public function generate($toshow=false){
		
		$im = imagecreatetruecolor(($this->chart_width + 50),($this->chart_height + 50));
		$white = imagecolorallocate($im, 255, 255, 255);
		$axis_lines = imagecolorallocate($im, 230, 230, 230);
		$black = imagecolorallocate($im, 0, 0, 0);
		imagesetthickness($im, "2");
		imagefilledrectangle($im, 0, 0,($this->chart_width + 50), ($this->chart_height + 50), $white);
		$this->init();
		if($this->type!="pie"){
		
		
		imageline($im, ($this->cbase_x - $this->cbar_gap), "0", ($this->cbase_x - $this->cbar_gap), ($this->cbase_y + 5), $axis_lines);
		imageline($im, ($this->cbase_x - $this->cbar_gap), ($this->cbase_y + 5), ($this->chart_width)+50, ($this->cbase_y + 5), $axis_lines);
		imagesetthickness($im, "1");
		$font_file = './verdana.ttf';
			for($i=$this->cbase_y;$i>5;$i=$i-20)
			{
				$val=(int)($i/$this->hzoom);
				if(strlen($val)>=4){$val=number_format($val/1000,1)."k";}
				imagefttext($im, 8, 0, ($this->cbase_x - $this->cbar_gap -30), ($this->cbase_y - $i ), $black, $font_file, $val);
			}
		}
		
		
		
		if($this->type=="bar"){$this->create_sets_bar($im);}
		if($this->type=="line"){$this->create_sets_line($im);}
		if($this->type=="line_bar"){$this->create_sets_bar($im);$this->create_sets_line($im);}
		if($this->type=="scatter"){$this->create_sets_scatter($im);}
		if($this->type=="pie"){$this->create_sets_pie($im);}
		if($this->type=="area"){$this->create_sets_area($im);$this->create_sets_line($im);}
		
		
		$file="cache/chart".session_id().".png";
		
		imagepng($im,$file,9);
		imagedestroy($im);
		if($toshow==true){echo '<img src="'.$file.'?q='.rand().'">'; }
	}
	
	
}
?>