<?php session_start(); ?>
<html>
	<head>
		<title>VectorChart :: version 0.1</title>
		 <style type="text/css"> 
		   body,td {font-family: Verdana; font-size:11px }
		   a{color:maroon;text-decoration:none;}a:hover{text-decoration:underline;}
		   input[type=text],select{ border:1px solid #999;padding:2px ;font-family: Verdana; font-size:11px}
		</style> 
	</head>
	<body>
		
		<?php
		$value="2001:66,2002:33,2003:15,2004:37";
		$ctype="bar";
		$width="300";
		$height="200";
		$fill="rgb(0,130,240)";
		$stroke="rgb(0,130,240)";
		$pie_fill="0,120,200";
		$pie_center="100,100";
		$cdtype="svg";

		if(isset($_POST['values']))
		{
			$value=$_POST['values'];
			$ctype=$_POST['type'];
			$width=$_POST['cwidth'];
			$height=$_POST['cheight'];
			$fill=$_POST['fill_color'];
			$stroke=$_POST['stroke_color'];
			$pie_fill=$_POST['pie_fill'];
			$pie_center=$_POST['pie_center'];
			$cdtype=$_POST['cdtype'];
			include("svg_charts.php");
			$obj=new SVGCharts($_POST['cwidth'],$_POST['cheight']);
			include("img_charts.php");
			$obj2=new JPGCharts($_POST['cwidth'],$_POST['cheight']);

			
			$obj->set("chart_type",$_POST['type']);
			$obj->set("fill_color",$_POST['fill_color']);
			$obj->set("stroke_color",$_POST['stroke_color']);
			$obj->set("pie_fill",$_POST['pie_fill']);	
			$obj->set("pie_center",$_POST['pie_center']);	
			
			$obj2->set("chart_type",$_POST['type']);
			$obj2->set("fill_color",$_POST['fill_color']);
			$obj2->set("stroke_color",$_POST['stroke_color']);
			$obj2->set("pie_fill",$_POST['pie_fill']);	
			$obj2->set("pie_center",$_POST['pie_center']);	
			
			$data=array();
			$arr=explode(",",$_POST['values']);
			$i=0;
			foreach($arr as $key=>$val)
			{
				$dats=explode(":",$val);
				$data['x'][$i]=$dats[0];
				$data['y'][$i]=$dats[1];
				$i++;
			}
			$obj->set("chart_data",$data);
			$obj2->set("chart_data",$data);
			if((int)strpos($_SERVER['HTTP_USER_AGENT'],"MSIE")>0){
				$obj2->generate(true);
			}else{
				$obj->generate();
				$obj2->generate(false);
			}
			
			?><br/>
			<a href="download.php">Download Chart</a>
			<?php
			
			
		}



		?>

		<form method="post">
		<?php /* 	Chart type:<br/>
			<select name="cdtype">	
				<option value="svg" <?php if($cdtype=="svg"){echo " selected";} ?>>SVG Chart</option>
				<option value="image" <?php if($cdtype=="image"){echo " selected";} ?>>Image Chart</option>
			</select> */ ?>
			<br/>
			<table>
				<tr>
					<td>Enter values(<i>2001:66,2002:33 etc.</i>):</td>
					<td>
						<input type="text" name="values" style="width:500px" value="<?php echo $value; ?>" /> 
						<select name="type">	
							<option value="bar" <?php if($ctype=="bar"){echo " selected";} ?>>Bar Chart</option>
							<option value="line" <?php if($ctype=="line"){echo " selected";} ?>>Line Chart</option>
							<option value="line_bar" <?php if($ctype=="line_bar"){echo " selected";} ?>>Bar & Line Chart</option>
							<option value="scatter" <?php if($ctype=="scatter"){echo " selected";} ?>>Scatter Chart</option>
							<option value="pie" <?php if($ctype=="pie"){echo " selected";} ?>>Pie</option>
							<option value="area" <?php if($ctype=="area"){echo " selected";} ?>>Area</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>Chart size:</td>
					<td>
						<input type="text" name="cwidth" value="<?php echo $width; ?>" style="width:50px" maxlength="4" /> x <input value="<?php echo $height; ?>" type="text" name="cheight" style="width:50px" maxlength="4" />
					</td>
				</tr>
				<tr>
					<td>Fill Color:</td>
					<td>
						 <input type="text" value="<?php echo $fill; ?>"  name="fill_color">
					</td>
				</tr>
				<tr>
					<td>Stroke Color:</td>
					<td>
						<input type="text" value="<?php echo $stroke; ?>"  name="stroke_color">
					</td>
				</tr>
				<tr>
					<td>Pie Fill:</td>
					<td>
						<select name="pie_fill">	
							<option value="red" <?php if($pie_fill=="red"){echo " selected";} ?>>Red</option>
							<option value="green" <?php if($pie_fill=="green"){echo " selected";} ?>>Green</option>
							<option value="blue" <?php if($pie_fill=="blue"){echo " selected";} ?>>Blue</option>
						</select>
					</td>
				</tr>
			</table>
			 <br/>
			
	
			<input type="submit" value="Submit">
		</form>
	</body>
<html>

