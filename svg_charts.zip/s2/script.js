var SVGDocument = null;
var SVGRoot = null;
var SVGViewBox = null;
var svgns = 'http://www.w3.org/2000/svg';
var xlinkns = 'http://www.w3.org/1999/xlink';
var TrueCoords = null;
var lastElement = null;
function Init(evt)
{
	SVGDocument = evt.target.ownerDocument;
	SVGRoot = document.documentElement;
	TrueCoords = SVGRoot.createSVGPoint();
};
function GetTrueCoords(evt)
{
	 var newScale = SVGRoot.currentScale;
	 var translation = SVGRoot.currentTranslate;
	 TrueCoords.x = (evt.clientX - translation.x)/newScale;
	 TrueCoords.y = (evt.clientY - translation.y)/newScale;
};
function showTip(evt,label,value){
	document.getElementById('ToolTip').setAttributeNS(null, 'transform', 'translate(' + (TrueCoords.x - 20) + ',' + (TrueCoords.y-50) + ')');
	document.getElementById('ToolTip').setAttributeNS(null, 'display', 'inline');
	var lbl=document.getElementById("evtText1");
	lbl.firstChild.nodeValue = label + ": ";
	
	lbl=document.getElementById("evtText2");
	lbl.firstChild.nodeValue = value;
}
function hideTip(){
	document.getElementById('ToolTip').setAttribute('display','none');
}