<?php
session_start();
class SVGCharts
{
	var $type;
	var $data;
	var $chart_data;
	var $x_data;
	var $y_data;
	var $chart_content;
	var $cbase_y;
	var $cbase_x;
	var $cbar_width;
	var $cbar_gap;
	var $chart_width;
	var $chart_height;
	var $fill_color;
	var $stroke_color;
	var $max_radius;
	var $max_val;
	var $hzoom;
	var $p_radius;
	var $pie_center;
	var $pie_shade;
	
	function __construct($width,$height)
	{
		$this->chart_width=$width;
		$this->chart_height=$height;
		$this->type="bar";
		$this->cbase_x="50";
		$this->cbar_width="10";
		$this->cbar_gap="15";
		$this->fill_color="rgb(0,130,240)";
		$this->stroke_color="rgb(150,0,0)";
		$this->max_radius="10";
		$this->p_radius="90";
		$this->pie_center=array('100','100');
		$this->pie_shade=array(0,120,200);
		
	}
	
	public function set($setType,$value)
	{
		switch($setType){
			case 'chart_type':$this->type=$value;break;
			case 'chart_data':$this->chart_data=$value;break;
			case 'max_height':$this->cbase_y=$value;break;
			case 'left_margin':$this->cbase_x=$value;break;
			case 'bar_width':$this->cbar_width=$value;break;
			case 'bar_gap':$this->cbar_gap=$value;break;
			case 'fill_color':$this->fill_color=$value;break;
			case 'stroke_color':$this->stroke_color=$value;break;
			case 'p_radius':$this->p_radius=$value;break;
			case 'pie_center':$this->pie_center=explode(",",$value);break;
			case 'pie_fill':{
				if($value=="red"){$this->pie_shade=array(250,0,0);}
				if($value=="green"){$this->pie_shade=array(0,250,0);}
				if($value=="blue"){$this->pie_shade=array(0,130,250);}
				break;
			};
		}
	}
	
	public function get($getType){
		switch($getType){
			case 'chart_type':return $this->type;break;
			case 'chart_data':return $this->chart_data;break;
		}
	}
	
	private function init(){
		$this->x_data=$this->chart_data['x'];
		$this->y_data=$this->chart_data['y'];
		$col_width=(int)$this->chart_width / sizeof($this->x_data);
		$this->cbar_width=$col_width-$this->cbar_gap;
		
		$this->cbase_y=0;
		$this->max_val=0;
		foreach($this->y_data as $key=>$val){
			if($val>$this->cbase_y){$this->cbase_y=$val;$this->max_val=$val;}
		}
		$this->cbase_y=$this->cbase_y * 1.3;
		$this->hzoom=$this->chart_height / $this->cbase_y;
		
		$this->cbase_y=$this->chart_height;
		$this->p_radius=(($this->chart_width-100)/2);
		$this->pie_center=array((($this->chart_width-100)/2),(($this->chart_height)/2));
	}
	
	private function create_sets_area()
	{
		$content='';

		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		
		$points=array();
		
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=$this->y_data[$i]*$this->hzoom;
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$points[$i]=array($x+ ($bar_width/2),$y);
		}
		
		$content.='<path d="M'.$points[0][0].','.$this->chart_height.' ';
		$last_x=0;
		foreach($points as $key=>$val){
			$content.='L'.$val[0].','.$val[1]." ";
			$last_x=$val[0];
		}
		$content.=' L'.$last_x.','.$this->chart_height.' z"	style="fill:'.$this->stroke_color.'; fill-opacity: .2;	stroke:none; stroke-width: 0"/>';
		
		return $content;
	}
	
	private function create_sets_pie()
	{
		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		$total=0;
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$total+=$this->y_data[$i];
		}
		
		$long=$this->p_radius;
		$def_x=$this->pie_center[0];
		$def_y=$this->pie_center[1] - $long;
		$colors=$this->pie_shade;
		$prev_deg=0;
		$content_text='';
		for($i=0;$i<sizeof($this->y_data);$i++)
		{
			$act_degree=($this->y_data[$i]/$total) * 360;
			$degrees=($act_degree) - 90 + $prev_deg;

			if($act_degree>180){
			
				for($j=0;$j<2;$j++)
				{
					$act_degree_2=$act_degree/2;
					$degrees_2=($act_degree_2) - 90 + $prev_deg;

					$y=$this->pie_center[1] + ($long*sin(deg2rad($degrees_2)));
					$x=$this->pie_center[0] + ($long*cos(deg2rad($degrees_2)));
					$prev_deg=$degrees_2 + 90;
					$content.='<path onmousemove="showTip(evt,\''.$this->x_data[$i].'\',\''.$this->y_data[$i].'\')" onmouseout="hideTip(evt)" d="M'.$this->pie_center[0].','.$this->pie_center[1].' L'.$def_x.','.$def_y.' A'.$long.','.$long.' 0 0,1 '.$x.','.$y.' z"
					style="fill:rgb('.$colors[0].','.$colors[1].','.$colors[2].');
					fill-opacity: 1;
					stroke:none;
					stroke-width: 0"/>';
					$def_x=$x;
					$def_y=$y;
					
					if($j==0){
						$yt=$this->pie_center[1] + ($long*sin(deg2rad($degrees_2)));
						$xt=$this->pie_center[0] + ($long*cos(deg2rad($degrees_2)));
						
						$ctx=($this->pie_center[0] + $xt)/2;
						$cty=($this->pie_center[1] + $yt)/2;
						$content_text.='<text  stroke="none" fill="#000000" style="font-weight:bold;color:#000;font-family:verdana;font-size:10px;display:inline" x="'.$ctx.'" y="'.$cty.'"><tspan>'.number_format(($this->y_data[$i]/$total) * 100,2).' %</tspan></text>';
					}
			
				}
			}else{
						
				$act_degreet=(($this->y_data[$i]/$total) * 360)/2;
				$degreest=($act_degreet) - 90 + $prev_deg;
				$yt=$this->pie_center[1] + ($long*sin(deg2rad($degreest)));
				$xt=$this->pie_center[0] + ($long*cos(deg2rad($degreest)));
				$content_text.='<text  stroke="none" fill="#000000" style="font-weight:bold;color:#000;font-family:verdana;font-size:10px;display:inline" x="'.$xt.'" y="'.$yt.'"><tspan>'.number_format(($this->y_data[$i]/$total) * 100,2).' %</tspan></text>';
			
			
				$y=$this->pie_center[1] + ($long*sin(deg2rad($degrees)));
				$x=$this->pie_center[0] + ($long*cos(deg2rad($degrees)));
				$prev_deg=$degrees + 90;
				
				$content.='<path onmousemove="showTip(evt,\''.$this->x_data[$i].'\',\''.$this->y_data[$i].'\')" onmouseout="hideTip(evt)" d="M'.$this->pie_center[0].','.$this->pie_center[1].' L'.$def_x.','.$def_y.' A'.$long.','.$long.' 0 0,1 '.$x.','.$y.' z"	style="fill:rgb('.$colors[0].','.$colors[1].','.$colors[2].'); fill-opacity: 1;stroke:none;stroke-width: 0;z-index:100"/>';
				
				
				
				
				$def_y=$y;
				$def_x=$x;
			}
			
			$content.='<text x="'.($this->chart_width-40) .'" y="'.(($i+1)*14).'" text-anchor="left" style="font: 11px Tahoma;" font="11px Tahoma" stroke="none" fill="#000000"><tspan>'.($this->x_data[$i]).'('.$this->y_data[$i].')</tspan></text>
			<rect  x="'.($this->chart_width-55).'" y="'.(($i+.3)*14).'" width="10" height="10" style="fill:rgb('.$colors[0].','.$colors[1].','.$colors[2].');stroke:#fff;stroke-width:1px;" ></rect>
			';
			
			if($colors[0]>0){$colors[0]=$colors[0] - 30;}
			if($colors[1]>0){$colors[1]=$colors[1] - 30;}
			if($colors[2]>0){$colors[2]=$colors[2] - 30;}
			
				
		}
		
		return $content.$content_text;
	}
	
	private function create_sets_scatter()
	{
		$content='';

		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=$this->y_data[$i]*$this->hzoom;
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$radius=(int)(($ro/($this->max_val*$this->hzoom)) * $this->max_radius);
			$content.='<circle cx="'.($x+($bar_width/2)).'" onmousemove="showTip(evt,\''.$this->x_data[$i].'\',\''.$this->y_data[$i].'\')" onmouseout="hideTip(evt)"  cy="'.$y.'" r="'.$radius.'" stroke="white" stroke-width="0" fill="'.$this->fill_color.'"/>';

			$content.='<text x="'.($x + ($bar_width/2)) .'" transform="rotate(-90 '.($x + ($bar_width/2)) .','.($base_y+30).')" y="'.($base_y+30).'" text-anchor="middle" style="font: 11px Tahoma;" font="11px Tahoma" stroke="none" fill="#000000"><tspan>'.($this->x_data[$i]).'</tspan></text>';

		}
		return $content;
	}
	
	private function create_sets_line()
	{
		$content='';
		
		$prev_x=0;
		$prev_y=0;
		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		$points=array();
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=$this->y_data[$i]*$this->hzoom;
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$points[$i]=array($x + ($bar_width/2),$y);
			if($prev_x!=0){
				$content.='<line x1="'. ($prev_x + ($bar_width/2)).'" y1="'.$prev_y.'" x2="'.($x+ ($bar_width/2)).'" y2="'.$y.'" style="stroke:'.$this->stroke_color.';stroke-width:4"/>';
				
			}
			$content.='<text x="'.($x + ($bar_width/2)) .'" transform="rotate(-90 '.($x + ($bar_width/2)) .','.($base_y+30).')" y="'.($base_y+30).'" text-anchor="middle" style="font: 11px Tahoma;" font="11px Tahoma" stroke="none" fill="#000000"><tspan>'.($this->x_data[$i]).'</tspan></text>';
			$prev_x=$x;	
			$prev_y=$y;
		}
		$i=0;
		foreach($points as $key=>$val){
			$content.='<circle cx="'.($val[0]).'" cy="'.$val[1].'" r="4" stroke-width="1.5" style="stroke:white" opacity="1" fill="'.$this->stroke_color.'" onmousemove="showTip(evt,\''.$this->x_data[$i].'\',\''.$this->y_data[$i].'\')" onmouseout="hideTip(evt);" />';
			$i++;
		}
		return $content;
	}
	
	private function create_sets_bar()
	{
		$content='';
		$base_y=$this->cbase_y;
		$base_x=$this->cbase_x;
		$bar_width=$this->cbar_width;
		$bar_gap=$this->cbar_gap;
		for($i=0;$i<sizeof($this->x_data);$i++)
		{
			$ro=($this->y_data[$i]*$this->hzoom);
			$y=$base_y-$ro;
			$h=$base_y-$y;
			$x=($base_x + (($bar_width + $bar_gap) * ($i)))-10;
			$content.='<rect onmousemove="showTip(evt,\''.$this->x_data[$i].'\',\''.$this->y_data[$i].'\')" onmouseout="hideTip(evt)" x="'.$x.'" y="'.$y.'" width="'.$bar_width.'" height="'.$h.'" style="fill:'.$this->fill_color.';stroke:#fff;stroke-width:1px;" ></rect>
			<text x="'.($x + ($bar_width/2)) .'" transform="rotate(-90 '.($x + ($bar_width/2)) .','.($base_y+30).')" y="'.($base_y+30).'" text-anchor="middle" style="font: 11px Tahoma;" font="11px Tahoma" stroke="none" fill="#000000"><tspan>'.($this->x_data[$i]).'</tspan></text>';
		}
		
		
		return $content;
	}
	
	public function generate(){
		
		$this->init();
		$head='<?xml version="1.0" standalone="no"?>
			<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
			<svg xmlns=\'http://www.w3.org/2000/svg\' xmlns:xlink=\'http://www.w3.org/1999/xlink\'  onload=\'Init(evt)\'  onmousemove="GetTrueCoords(evt);">
			<script xlink:href="../script.js"/>
					
			<g id="viewport" onmousemove="GetTrueCoords(evt);">
			';
		if($this->type!="pie"){
			$container='<line x1="'. ($this->cbase_x - $this->cbar_gap ).'" y1="0" x2="'.($this->cbase_x - $this->cbar_gap ).'" y2="'.($this->cbase_y + 5).'" style="stroke:#ccc;stroke-width:1"/>
	<line x1="'. ($this->cbase_x - $this->cbar_gap ).'" y1="'.($this->cbase_y + 5).'" x2="'.($this->cbase_x + (($this->cbar_width + $this->cbar_gap) * (sizeof($this->x_data) + 1)) ).'" y2="'.($this->cbase_y + 5).'" style="stroke:#ccc;stroke-width:1"/>
	';
			for($i=$this->cbase_y;$i>5;$i=$i-20)
			{
			
				$val=(int)($i/$this->hzoom);
				if(strlen($val)>=4){$val=number_format($val/1000,1)."k";}
		
				$container.='<text x="'.($this->cbase_x - $this->cbar_gap -20) .'" y="'.($this->cbase_y - $i + 10).'" text-anchor="middle" style="font: 11px Tahoma;" font="11px Tahoma" stroke="none" fill="#000000"><tspan>'.$val.'</tspan></text>
				';
			}
		}
		
		$foot='</g>
		<g id="ToolTip" opacity="0.95" display="none" pointer-events="none"><rect id="tipbox" x="0" y="5" width="80" height="35" rx="2" ry="2" fill="#444" stroke="#000" />
			<text x="5" y="18" id="evtText1" style="font: 10px Tahoma;text-decoration:underline" stroke="none" fill="#fff">:</text>
			<text x="5" y="32" id="evtText2" style="font: 9px Tahoma;" stroke="none" fill="#fff">:</text>
		</g>
		</svg>';
		
		if($this->type=="bar"){$this->chart_content=$this->create_sets_bar();}
		if($this->type=="line"){$this->chart_content=$this->create_sets_line();}
		if($this->type=="line_bar"){$this->chart_content=$this->create_sets_bar().$this->create_sets_line();}
		if($this->type=="scatter"){$this->chart_content=$this->create_sets_scatter();}
		if($this->type=="pie"){$this->chart_content=$this->create_sets_pie();}
		if($this->type=="area"){$this->chart_content=$this->create_sets_area().$this->create_sets_line();}
		
		
		$svg_content=$head.$this->chart_content.$container.$foot;
		$file="cache/chart".session_id().".svg";
		$fp=fopen($file,"w");
		fwrite($fp,$svg_content);
		fclose($fp);
		echo '<embed src="'.$file.'" width="'.($this->chart_width + 50).'" height="'.($this->chart_height + 50).'" type="image/svg+xml" pluginspage="http://www.adobe.com/svg/viewer/install/" />';

	}
	
	
}
?>