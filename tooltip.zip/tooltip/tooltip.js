jQuery(document).ready(function(){
	jQuery('.tooltip').each(function(){
		content=jQuery(this).html();
		jQuery(this).html('<div class="tip_text">'+content+'</div>');
		jQuery(this).mousemove(function(){
			jQuery(this).find(".tip_text").show();
		})
		jQuery(this).mouseout(function(){
			jQuery(this).find(".tip_text").hide();
		})
	})
})