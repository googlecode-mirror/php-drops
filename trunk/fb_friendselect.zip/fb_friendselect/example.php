<html>
	<head>
		<title>PHP Drops :: Facebook style friend select</title>
		<script type="text/javascript" src="jquery-1.3.2.js" ></script>
		<script type="text/javascript" src="script.js" ></script>
		<link type="text/style" href="style.css" rel="stylesheet" />
	</head>
	<body>
		<?php
		if(isset($_POST)){
			echo "<pre>";
			print_r($_POST['friend']);
			echo "</pre>";
		}
		?>
		<form method="post">
		<h3>Facebook Style Friend Select</h3>
		Type name of your friend: <input type="text" id="friend_name" /><br/>
		<div class="friend_container">
			<ul>
				<li>
					<div>
						<div style="float:left;width:70px"><img src="images/sample.jpg" width="60"></div>
						<div style="float:left;width:70px;"><input type="checkbox" name="friend[]"value="1">Arial Smith</div>
					</div>
				</li>
				<li>
					<div>
						<div style="float:left;width:70px"><img src="images/sample.jpg" width="60"></div>
						<div style="float:left;width:70px;"><input type="checkbox" name="friend[]"value="2">Aron Buxton</div>
					</div>
				</li>
				<li>
					<div>
						<div style="float:left;width:70px"><img src="images/sample.jpg" width="60"></div>
						<div style="float:left;width:70px;"><input type="checkbox" name="friend[]"value="3">Camela Johnson</div>
					</div>
				</li>
				<li>
					<div>
						<div style="float:left;width:70px"><img src="images/sample.jpg" width="60"></div>
						<div style="float:left;width:70px;"><input type="checkbox" name="friend[]"value="4">Helen Miller</div>
					</div>
				</li>
				<li>
					<div>
						<div style="float:left;width:70px"><img src="images/sample.jpg" width="60"></div>
						<div style="float:left;width:70px;"><input type="checkbox" name="friend[]"value="5">Mitchel Fox</div>
					</div>
				</li>
				<li>
					<div>
						<div style="float:left;width:70px"><img src="images/sample.jpg" width="60"></div>
						<div style="float:left;width:70px;"><input type="checkbox" name="friend[]" value="6">Monic Mona</div>
					</div>
				</li>
				
			</ul>
		</div><div style="clear:both"></div>
		<input type="submit" value="Send Request" />
		</form>
	</body>
</html>

