jQuery(document).ready(function(){
	jQuery('.friend_container ul li').click(function(){
		jQuery(this).toggleClass("active");
		if(jQuery(this).find("input[type=checkbox]").attr("checked")==true){
			jQuery(this).find("input[type=checkbox]").removeAttr("checked");
		}else{
			jQuery(this).find("input[type=checkbox]").attr("checked","checked");
		}
	})
	
	jQuery('#friend_name').keyup(function(){
		var typed=jQuery(this).val();
		if(typed==""){
			jQuery('.friend_container ul li').show();
		}else{
			jQuery('.friend_container ul li').hide();
			
			jQuery(".friend_container ul li").each(function(){
				var name=jQuery(this).find("div:last").text();
				if((name.substr(0,typed.length)).toLowerCase()==typed.toLowerCase()){
					jQuery(this).show();
				}
			});
		}
	})
})