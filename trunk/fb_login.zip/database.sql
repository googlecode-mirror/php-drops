
DROP TABLE IF EXISTS `fb_registered_user`;
CREATE TABLE IF NOT EXISTS `fb_registered_user` (
  `id` int(10) NOT NULL auto_increment,
  `dt` date default NULL,
  `email` varchar(100) collate latin1_general_ci default NULL,
  `password` varchar(30) collate latin1_general_ci default NULL,
  `first_name` varchar(30) collate latin1_general_ci default NULL,
  `last_name` varchar(30) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
);

