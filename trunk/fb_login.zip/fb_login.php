<?php
function generateString($length=9, $strength=1) {
	$vowels = 'aeuy';
	$consonants = 'bdghjmnpqrstvzaeuy';
	if ($strength == 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength == 2) {
		$vowels .= "AEUY";
	}
	if ($strength == 4) {
		$consonants .= '23456789';
	}
	if ($strength == 8) {
		$consonants .= '@#$%';
	}
 
	$wrd = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		$wrd .= $consonants[(rand() % strlen($consonants))];
		$alt = 0;
	}
	return $wrd;
}


require 'src/facebook.php';
$facebook = new Facebook(array('appId'  => 'YOUR_API_KEY','secret' => 'YOUR_SECRET_KEY','cookie' => true,));
$session = $facebook->getSession();
$me = null;
if ($session) {
  try {
    $uid = $facebook->getUser();
    $me = $facebook->api('/me');
  } catch (FacebookApiException $e) {
    error_log($e);
  }
}

if ($me) {
  $logoutUrl = $facebook->getLogoutUrl();
} else {
	$loginUrl = $facebook->getLoginUrl();
}
?>
<html>
  <head>
    <title>PHP Drops :: Facebook Connect (Demo)</title>
    <style type="text/css">
      body {font-family: Trebuchet MS; font-size:12px }
      </style>
  </head>
  <body>
    <?php if ($me): 
	?>
       You have been successfully logged into facebook. [<a href="<?php echo $logoutUrl; ?>">Logout</a>]
	   <h1>User Details</h1>
	   <?php
	   mysql_connect("localhost","root");
		mysql_select_db("test");
		if(!mysql_fetch_array(mysql_query("select id from fb_registered_user where email='".$me['email']."'"))){
			$q="insert into fb_registered_user set first_name='".$me['first_name']."', last_name='".$me['last_name']."',email='".$me['email']."',dt=curdate(), password='".generateString()."'";
			mysql_query($q);
			echo '<div style="color:green">User has been successfully registered.</div>';
		}
	   
	   ?>
		<table>
			<tr>
				<td valign="top">
					<img src="https://graph.facebook.com/<?php echo $me['username']; ?>/picture">
				</td>
				<td valign="top">
					<b>Name:</b> <?php echo $me['first_name']." ".$me['last_name']; ?><br/>
					<b>Email:</b> <?php echo $me['email']; ?>
				</td>
			</tr>
		</table>
    <?php else: ?>
    <div>
      You are currently not logged in. Click <a href="<?php echo $loginUrl; ?>">here</a> to login using facebook connect.
    </div>
    <?php endif; ?>
	</body>
</html>
