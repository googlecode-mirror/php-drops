<?php
require 'src/facebook.php';
$facebook = new Facebook(array('appId'  => 'YOUR_APP_ID','secret' => 'YOUR_SECRET_KEY','cookie' => true,));
$session = $facebook->getSession();
$me = null;
if ($session) {
  try {
    $uid = $facebook->getUser();
    $me = $facebook->api('/me');
  } catch (FacebookApiException $e) {
    error_log($e);
  }
}

if ($me) {
  $logoutUrl = $facebook->getLogoutUrl();
} else {
	$loginUrl = $facebook->getLoginUrl();

}
?>
<html>
  <head>
    <title>PHP Drops :: Facebook Connect (Demo)</title>
    <style type="text/css">
      body,td {font-family: Trebuchet MS; font-size:12px }
      .posting_window {background:#fff;width:300px;height:210px;border:8px solid rgb(0,100,200);position:absolute;top:-11px;left:-11px;overflow:hidden;display:none;z-index:200;-moz-border-radius: 10px;-webkit-border-radius: 10px;-khtml-border-radius: 10px;-moz-box-shadow:0 0 15px #0099FF;-webkit-box-shadow: 0px 0px 15px #0099ff;box-shadow: 0px 0px 15px #0099ff; }
    </style>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  </head>
  <body>
    <?php if ($me): ?>
       You have been successfully logged in. [<a href="<?php echo $logoutUrl; ?>">Logout</a>]
	   <h1>User Details</h1>
		<table>
			<tr>
				<td valign="top">
					<img src="https://graph.facebook.com/<?php echo $uid; ?>/picture">
				</td>
				<td valign="top">
					<b>Name:</b> <?php echo $me['first_name']." ".$me['last_name']; ?><br/>
					<b>Email:</b> <?php echo $me['email']; ?>
				</td>
			</tr>
		</table>
		<h1>Page Admins</h1>
		<form method="post" action="">
		<?php
		
		if (isset($_POST['status']))
		{
		
			$tot=0;
			$success=0;
			foreach($_POST['pages'] as $key=>$val)
			{
				$tot++;
				try {
					$statusUpdate = $facebook->api('/'.$val.'/feed', 'post', array('message'=> $_POST['status'], 'cb' => ''));
				} catch (FacebookApiException $e) {
					echo "<div style='color:red'>Error!! Status update failed.</div>";
				}
				if(!empty($statusUpdate)){
					$success++;
				}
			}	
			echo "Status: $success status updated";
				
		}
		
		try{ 
            $fql    =   "select page_id, name, pic_small, type from page where type<>'APPLICATION' and page_id in (select page_id from page_admin where uid =" . $uid . ")";
            $param  =   array(
                'method'    => 'fql.query',
                'query'     => $fql,
                'callback'  => ''
            );
            $page_list   =   $facebook->api($param);
        }
        catch(Exception $o){
            d($o);
        }
		$i=1;
		shuffle($page_list);
		foreach($page_list as $rec){
		
			if(($i-1)%10==0){
				echo '</ul><div style="clear:both"></div><ul style="padding:0px">';
			}
		
			?>
			<li style="float:left;list-style:none;margin:5px;position:relative;width:250px">
				<div style="float:left"><input type="checkbox" name="pages[]" value="<?php echo $rec['page_id']; ?>"></div>
				<div style="float:left;margin-left:5px"><img src="<?php echo $rec['pic_small']; ?>" title="<?php echo $rec['name']; ?>" border="0"></div>
				<div style="float:left;margin-left:5px;width:150px"><b><?php echo $rec['name']; ?></b><br/><?php echo $rec['type']; ?></div>
			</li>
			<?php
			$i++;
		}
		?>
		<br style="clear:both" />
			<textarea name="status" style="border:1px solid #ccc;width:600px" rows="4"></textarea><br/><br/>
			<input type="submit" value="Post in Wall">
		</form>
		
	
	
	
		
    <?php else: ?>
    <div>
      You are currently not logged in. Click <a href="<?php echo $loginUrl; ?>">here</a> to login using facebook connect.
    </div>
    <?php endif; ?>
	
	
	


    

  </body>
</html>
