<?php @include("gmap.php"); ?>
<html>
	<head>
		<title>PHP Drops :: GMap made easy </title>
		<script src="http://maps.google.com/maps?file=api&v=2&sensor=true_or_false&key=ABQIAAAA6ZWu_K9bMOH-c3yhzQpqwBT2yXp_ZAY8_ufC3CFXhHIE1NvwkxS1P19CiJNnCG0Rhe9XEF_VgWVCKg" type="text/javascript"></script>	
		<script type="text/javascript">
			function saveCoords(pid,new_points){
				alert("Pointer ID: "+pid+"\nNew Coordinates: ("+new_points+")")
			}
		</script>
		<style type="text/css">	
		body,td{font-family: Trebuchet MS;font-size:11px}
		</style>	
	</head>
	<body>
			<h1>PHP Drops Google Maps made easy</h1>	
			<table width="930" align="center">		
				<tr>
					<td width="300">Map 1(Single Pointer)</td>
					<td width="300">Map 2(Single Custom Pointer)</td>
					<td width="300">Map 3(Single Draggable Pointer)</td>
				</tr>
				<tr>
					<td><div style="width:250px;height:200px;border:1px solid" id="map1"></div></td>
					<td><div style="width:250px;height:200px;border:1px solid" id="map2"></td>
					<td><div style="width:250px;height:200px;border:1px solid" id="map3"></td>
				</tr>
				<tr>
					<td width="300">Map 4(Multiple Pointer)</td>
					<td width="300">Map 5(Multiple Custom Pointer)</td>
					<td width="300">Map 6(Multiple Draggable Pointer)</td>
				</tr>
				<tr>
					<td><div style="width:250px;height:200px;border:1px solid" id="map4"></div></td>
					<td><div style="width:250px;height:200px;border:1px solid" id="map5"></td>
					<td><div style="width:250px;height:200px;border:1px solid" id="map6"></td>
				</tr>
			</table>	
			
			<?php
				$center[0]="-37.773683";
				$center[1]="144.889455";
				
				$points=array();
				$points[0][0]="-37.773683";
				$points[0][1]="144.889455";
				generateMap($center,$points,"map1");
				
				$points=array();
				$center[0]="-37.773683";
				$center[1]="144.889455";
				$points[0][0]="-37.773683";
				$points[0][1]="144.889455";
				$points[0][2]="images/marker.png";
				generateMap($center,$points,"map2");
				
				$points=array();
				$center[0]="-37.773683";
				$center[1]="144.889455";
				$points[0][0]="-37.773683";
				$points[0][1]="144.889455";
				$points[0][2]="null";
				$points[0][3]="saveCoords:P912";
				generateMap($center,$points,"map3");
				
							
				$points=array();
				$points[0][0]="-37.773683";
				$points[0][1]="144.889455";
				$points[1][0]="-37.775683";
				$points[1][1]="144.891055";
				generateMap($center,$points,"map4");
				
				
				$points=array();
				$points[0][0]="-37.773683";
				$points[0][1]="144.889455";
				$points[0][2]="images/marker.png";
				$points[1][0]="-37.775683";
				$points[1][1]="144.891055";
				generateMap($center,$points,"map5");
				
				
				$points=array();
				$points[0][0]="-37.773683";
				$points[0][1]="144.889455";
				$points[0][2]="images/marker.png";
				$points[0][3]="saveCoords:P122";
				
				$points[1][0]="-37.775683";
				$points[1][1]="144.891055";
				
				$points[2][0]="-37.771683";
				$points[2][1]="144.891055";
				$points[2][2]="null";
				$points[2][3]="saveCoords:P964";
				generateMap($center,$points,"map6");
			?>
	</body>
</html>

