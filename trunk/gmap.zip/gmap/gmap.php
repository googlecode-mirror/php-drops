<?php
function generateMap($center,$points,$divid){
$str='<script type="text/javascript">if (GBrowserIsCompatible()) {
			var map = new GMap2(document.getElementById("'.$divid.'"));
			map.setCenter(new GLatLng('.$center[0].','.$center[1].'), 15);
			map.addControl(new GLargeMapControl3D());';
		$i=0;		
		foreach($points as $rec)
		{
			$i++;	
			$param=array();
			if(sizeof($rec)==4){
				$param[]="draggable: true";
			}
			if(sizeof($rec)>=3 && $rec[2]!="null"){
				$str.="var markerN = new GIcon(G_DEFAULT_ICON);
						markerN.iconAnchor = new GPoint(0, 0);
						markerN.infoWindowAnchor = new GPoint(0,0);
						markerN.image = '".$rec['2']."';";
				$param[]="icon: markerN";
			}
			$str.='
					var marker_pt'.$i.' = new GMarker( new GLatLng('.$rec[0].','.$rec[1].'),{'.implode(",",$param).'});
					map.addOverlay(marker_pt'.$i.');
				';
			if(sizeof($rec)==4){
				$param_arr=explode(":",$rec[3]);
				$str.='
						GEvent.addListener(marker_pt'.$i.', "dragend", function(latLng) {
							var newPoint=latLng.toString();
							newPoint=newPoint.substr(1);
							newPoint=newPoint.substr(0,newPoint.length-2);
							setTimeout("'.$param_arr[0].'(\''.$param_arr[1].'\',\'"+newPoint+"\')",100);
						  });
				
				';
			}
		}
		$str.="}</script>";
		echo $str;	
}
?>
