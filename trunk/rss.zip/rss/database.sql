# --------------------------------------------------------
# Host:                         localhost
# Database:                     test
# Server version:               5.0.51
# Server OS:                    Win32
# HeidiSQL version:             5.0.0.3272
# Date/time:                    2011-04-14 00:28:05
# --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

# Dumping structure for table test.rss
DROP TABLE IF EXISTS `rss`;
CREATE TABLE IF NOT EXISTS `rss` (
  `id` int(10) NOT NULL auto_increment,
  `movie_name` varchar(100) collate latin1_general_ci default NULL,
  `category` varchar(50) collate latin1_general_ci default NULL,
  `pic` varchar(50) collate latin1_general_ci default NULL,
  `link` varchar(100) collate latin1_general_ci default NULL,
  `description` varchar(300) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

# Dumping data for table test.rss: 8 rows
DELETE FROM `rss`;
/*!40000 ALTER TABLE `rss` DISABLE KEYS */;
INSERT INTO `rss` (`id`, `movie_name`, `category`, `pic`, `link`, `description`) VALUES (1, 'The Nutty Professor', 'Comedy', 'thumbnail01.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (2, 'Click', 'Comedy', 'thumbnail02.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (3, 'Meet the Parents', 'Comedy', 'thumbnail03.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (4, 'John Rambo', 'Action', 'thumbnail04.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (5, 'G.I.Joe', 'Action', 'thumbnail05.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (6, 'The Exorcist', 'Horror', 'thumbnail06.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (7, 'The Amityville Horror', 'Horror', 'thumbnail07.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis '), (8, 'The Omen', 'Horror', 'thumbnail08.jpg', 'http://php-drops.blogspot.com', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis ');
/*!40000 ALTER TABLE `rss` ENABLE KEYS */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
