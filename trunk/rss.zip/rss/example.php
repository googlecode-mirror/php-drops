<?php
mysql_connect("localhost","root");
mysql_select_db("test");

$condition="";
if($_GET['q']!="all"){
	$condition=$_GET['q'];
}

$q="select * from rss where category='".$condition."' or ''='".$condition."'";
$records=mysql_query($q);
?>
<rss version="2.0"> 
	<channel> 
	  <title><?php echo "PHP Drops :: ".ucwords($condition).' Movies'; ?></title> 
	  <link><?php echo "http://".$_SERVER['SERVER_NAME']; ?></link> 
	  <description><?php echo "PHP DROPS :: Generating RSS feed for Movies (SAMPLE)" ?></description>
	  
	  <language>en-us</language> 
	  <pubDate>Wednesday, 13 April 2011 04:00:00 GMT</pubDate> 
	  <lastBuildDate>Wednesday, 13 April 2011 04:00:00 GMT</lastBuildDate> 
	<?php
	while($movie=mysql_fetch_array($records)){
		?>
		<item> 
         <title><?php echo $movie['movie_name'];?></title> 
         <link><?php echo $movie['link'];?></link> 
         <description><?php echo htmlentities('<table width="700"><tr><td width="50"><img src="thumbnails/'.$movie['pic'].'" width="50"></td><td valign="top">'.$movie['description'].'</td></tr></table>');?></description> 
         <pubDate>Wednesday, 13 April 2011 04:00:00 GMT</pubDate> 
      </item> 
		<?php
	}
	?>
	</channel> 
</rss>