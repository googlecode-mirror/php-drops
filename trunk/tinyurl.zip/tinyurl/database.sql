DROP TABLE IF EXISTS `tinyurls`;
CREATE TABLE IF NOT EXISTS `tinyurls` (
  `id` int(10) NOT NULL auto_increment,
  `shorturl` varchar(20) collate latin1_general_ci default NULL,
  `actualurl` varchar(500) collate latin1_general_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
