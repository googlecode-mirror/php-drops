<?php
mysql_connect("localhost","root");
mysql_select_db("test");

$url=$_GET['url'];
$url_details=mysql_fetch_array(mysql_query("select * from tinyurls where shorturl like ('".$url."')"));
if(!empty($url_details)){
	header("location: ".$url_details['actualurl']);
}else{
	echo '<h2 style="color:red">Error 404: Page not found</h2>';
}
?>