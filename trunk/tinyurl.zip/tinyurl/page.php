<?php
if(isset($_POST['url'])){
mysql_connect("localhost","root");
mysql_select_db("test");

	$exist=mysql_fetch_array(mysql_query("select * from tinyurls where actualurl='".$_POST['url']."'"));
	if(empty($exist))
	{
		function get_random_word($length=6){
			$chars='abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$word="";
			for($i=0;$i<$length;$i++){
				$word.=substr($chars,rand(1,strlen($chars)),1);
			}
			
			$isexist=mysql_fetch_array(mysql_query("select id from tinyurls where shorturl like ('".$word."')"));
			if(empty($isexist)){
				return $word;
			}else{
				return "";
			}
		}
		
		$tiny_word="";
		while($tiny_word==""){	
			$tiny_word=get_random_word();
		}
		mysql_query("insert into tinyurls set shorturl='".$tiny_word."', actualurl='".$_POST['url']."'");
	}else{
		$tiny_word=$exist['shorturl'];
	}
	echo "TinyURL: http://".$_SERVER['SERVER_NAME']."/php/tinyurl/".$tiny_word."<br/><br/>";
}
?>
<html>
	<head><title>Shorten URL</title></head>
	<body>
		<form method="post" action="">
			Enter the URL:<br/>
			<input type="text" name="url" style="padding:5px;width:500px"/><br/><br/>
			<input type="submit" style="padding:5px" value="Shorten URL">
		</form>
	</body>
</html>